<?php

require_once 'veriffmedia.civix.php';

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Implements hook_civicrm_config().
 */
function veriffmedia_civicrm_config(&$config): void {
  _veriffmedia_civix_civicrm_config($config);
}

/**
 * Implements hook_civicrm_cron().
 *
 * Führt den automatischen Bild-Import aus – aber nur, wenn er in den
 * Einstellungen aktiviert ist (veriffmedia_auto_enabled) und das eingestellte
 * Mindestintervall seit dem letzten Lauf verstrichen ist.
 *
 * Bewusst über den Cron-Hook statt über eine eigene APIv3-Job-Funktion, weil
 * die API-Auflösung selbstgebauter Job-Actions in neueren CiviCRM-Versionen
 * unzuverlässig ist ("API (Job, ...) does not exist").
 */
function veriffmedia_civicrm_cron(): void {
  // Standardmäßig AUS – muss bewusst aktiviert werden.
  if (!Civi::settings()->get('veriffmedia_auto_enabled')) {
    return;
  }

  // Mindestabstand zwischen zwei Läufen (in Minuten); Schutz vor zu häufiger
  // Ausführung, falls der System-Cron sehr engmaschig läuft.
  $intervalMin = (int) Civi::settings()->get('veriffmedia_auto_interval_min');
  if ($intervalMin < 1) {
    $intervalMin = 60;
  }
  $last = (int) Civi::settings()->get('veriffmedia_auto_last_run');
  $now = time();
  if ($last && ($now - $last) < ($intervalMin * 60)) {
    return;
  }

  // Lauf-Zeitpunkt sofort setzen, damit parallele Cron-Ticks sich nicht
  // überschneiden.
  Civi::settings()->set('veriffmedia_auto_last_run', $now);

  try {
    $limit = (int) Civi::settings()->get('veriffmedia_auto_limit');
    if ($limit < 1) {
      $limit = 100;
    }
    CRM_Veriffmedia_Sync::run($limit, NULL);
  }
  catch (\Throwable $e) {
    Civi::log()->warning('[veriffmedia] Automatischer Sync fehlgeschlagen: ' . $e->getMessage());
  }
}

/**
 * Implements hook_civicrm_install().
 *
 * Legt die Custom-Field-Gruppe "Veriff-Verifikation" mit drei File-Feldern
 * (Selfie, Ausweis Vorderseite, Ausweis Rückseite) am Kontakt an.
 */
function veriffmedia_civicrm_install(): void {
  _veriffmedia_civix_civicrm_install();
  _veriffmedia_ensure_custom_fields();
}

/**
 * Implements hook_civicrm_enable().
 */
function veriffmedia_civicrm_enable(): void {
  _veriffmedia_civix_civicrm_enable();
  // Falls die Gruppe beim Install (z.B. nach Fehler) fehlt: nachziehen.
  _veriffmedia_ensure_custom_fields();
}

/**
 * Erstellt – idempotent – die Custom-Field-Gruppe und die drei File-Felder.
 *
 * Wird bei Install UND Enable aufgerufen; prüft vorher auf Existenz, damit
 * ein erneuter Aufruf keine Duplikate erzeugt.
 */
function _veriffmedia_ensure_custom_fields(): void {
  $groupName = 'veriff_verifikation';

  // 1. Existiert die Gruppe schon?
  $existing = \Civi\Api4\CustomGroup::get(FALSE)
    ->addWhere('name', '=', $groupName)
    ->addSelect('id')
    ->execute()
    ->first();

  if ($existing) {
    $groupId = $existing['id'];
  }
  else {
    $group = \Civi\Api4\CustomGroup::create(FALSE)
      ->addValue('name', $groupName)
      ->addValue('title', E::ts('Veriff-Verifikation'))
      ->addValue('extends', 'Contact')
      ->addValue('style', 'Inline')
      ->addValue('collapse_display', FALSE)
      ->addValue('is_active', TRUE)
      ->addValue('help_pre', E::ts('Von Veriff abgerufene Verifikationsdokumente. Sensible personenbezogene Daten – Zugriff beschränken.'))
      ->execute()
      ->first();
    $groupId = $group['id'];
  }

  // 2. Die drei Felder definieren (name => label)
  $fields = [
    'veriff_selfie'        => E::ts('Selfie-Foto'),
    'veriff_document_front' => E::ts('Ausweis Vorderseite'),
    'veriff_document_back'  => E::ts('Ausweis Rückseite'),
  ];

  $weight = 1;
  foreach ($fields as $fieldName => $label) {
    $fieldExists = \Civi\Api4\CustomField::get(FALSE)
      ->addWhere('custom_group_id', '=', $groupId)
      ->addWhere('name', '=', $fieldName)
      ->addSelect('id')
      ->execute()
      ->first();

    if ($fieldExists) {
      $weight++;
      continue;
    }

    \Civi\Api4\CustomField::create(FALSE)
      ->addValue('custom_group_id', $groupId)
      ->addValue('name', $fieldName)
      ->addValue('label', $label)
      ->addValue('data_type', 'File')
      ->addValue('html_type', 'File')
      ->addValue('is_active', TRUE)
      ->addValue('is_searchable', FALSE)
      ->addValue('is_search_range', FALSE)
      ->addValue('weight', $weight)
      ->addValue('note_columns', 60)
      ->addValue('note_rows', 4)
      ->execute();

    $weight++;
  }
}

/**
 * Implements hook_civicrm_pageRun().
 *
 * Fügt auf der Kontakt-Detailseite ein Panel ein, über das man eine
 * Veriff-Session-ID eingeben und den Bild-Import auslösen kann.
 */
function veriffmedia_civicrm_pageRun(&$page): void {
  if (get_class($page) !== 'CRM_Contact_Page_View_Summary') {
    return;
  }

  $contactId = (int) $page->getVar('_contactId');
  if (!$contactId) {
    return;
  }

  // Nur zeigen, wenn der Nutzer den Kontakt bearbeiten darf.
  if (!CRM_Contact_BAO_Contact_Permission::allow($contactId, CRM_Core_Permission::EDIT)) {
    return;
  }

  // Alles hier defensiv kapseln: Ein Fehler (z.B. beim Lesen aus der
  // WordPress-Tabelle) darf NIEMALS die Kontakt-Detailseite blockieren.
  try {
    $importUrl = CRM_Utils_System::url('civicrm/veriffmedia/import', NULL, FALSE, NULL, FALSE);
    $qfKey = CRM_Core_Key::get('veriffmedia_import');

    // Prüfen, ob das WordPress-Plugin bereits eine Session zu diesem Kontakt hat.
    $sessionInfo = CRM_Veriffmedia_WpBridge::getLatestSessionInfoForContact($contactId);

    Civi::resources()
      ->addScriptFile('de.gutmenschen.veriffmedia', 'js/contact-import.js', 100, 'html-header')
      ->addStyleFile('de.gutmenschen.veriffmedia', 'css/veriffmedia.css')
      ->addVars('veriffmedia', [
        'contactId' => $contactId,
        'importUrl' => $importUrl,
        'qfKey' => $qfKey,
        'hasSession' => $sessionInfo ? TRUE : FALSE,
        'sessionStatus' => $sessionInfo['status'] ?? '',
      ]);
  }
  catch (\Throwable $e) {
    // Panel wird in diesem Fall nicht angezeigt; die Kontaktseite bleibt heil.
    Civi::log()->warning('[veriffmedia] Panel konnte nicht eingefügt werden: ' . $e->getMessage());
  }
}

/**
 * Implements hook_civicrm_uninstall().
 *
 * Wir löschen die Custom-Felder bewusst NICHT automatisch mit, damit bereits
 * hinterlegte Dokumente bei einem versehentlichen Deinstallieren nicht
 * verloren gehen. Entfernen kann man sie manuell unter
 * "Datenverwaltung und Masken anpassen" → "Benutzerdefinierte Felder".
 */
function veriffmedia_civicrm_uninstall(): void {
  _veriffmedia_civix_civicrm_uninstall();
}

