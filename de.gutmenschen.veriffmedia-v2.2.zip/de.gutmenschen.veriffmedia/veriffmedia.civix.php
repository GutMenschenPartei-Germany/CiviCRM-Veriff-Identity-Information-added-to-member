<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Autoload/Utility-Klasse der Extension.
 * Von civix generierte Standard-Boilerplate (gekürzt auf das Nötige).
 */
class CRM_Veriffmedia_ExtensionUtil {

  const SHORT_NAME = 'veriffmedia';
  const LONG_NAME = 'de.gutmenschen.veriffmedia';
  const CLASS_PREFIX = 'CRM_Veriffmedia';

  /**
   * Übersetzung.
   */
  public static function ts($text, $params = []): string {
    if (!array_key_exists('domain', $params)) {
      $params['domain'] = [self::LONG_NAME, NULL];
    }
    return ts($text, $params);
  }

  /**
   * URL zu einer Ressource dieser Extension.
   */
  public static function url($file = NULL): string {
    if ($file === NULL) {
      return rtrim(CRM_Core_Resources::singleton()->getUrl(self::LONG_NAME), '/');
    }
    return CRM_Core_Resources::singleton()->getUrl(self::LONG_NAME, $file);
  }

  /**
   * Pfad zu einer Datei dieser Extension.
   */
  public static function path($file = NULL): string {
    return CRM_Core_Resources::singleton()->getPath(self::LONG_NAME, $file);
  }

  /**
   * Symbolischer Name.
   */
  public static function findClass($suffix): string {
    return self::CLASS_PREFIX . '_' . str_replace('/', '_', $suffix);
  }

}

function _veriffmedia_civix_civicrm_config($config = NULL): void {
  static $configured = FALSE;
  if ($configured) {
    return;
  }
  $configured = TRUE;

  $extRoot = __DIR__ . DIRECTORY_SEPARATOR;
  $include_path = $extRoot . PATH_SEPARATOR . get_include_path();
  set_include_path($include_path);

  // WICHTIG: Hier wird bewusst NICHT Smartys template_dir manipuliert.
  // Unter Smarty5 (CiviCRM 6.x) ist diese Eigenschaft geschützt; ein Zugriff
  // per setTemplateDir()/getTemplateVars('template_dir') überschreibt bzw.
  // zerstört die Verzeichnisliste und führt dazu, dass CiviCRM nicht einmal
  // mehr seine eigenen Kern-Templates laden kann (Fatal: "Unable to load
  // file:CRM/common/...tpl"). Die templates/-Ordner aktiver Extensions werden
  // von CiviCRM-Core ohnehin automatisch registriert.
}

function _veriffmedia_civix_civicrm_install(): void {
  _veriffmedia_civix_civicrm_config();
}

function _veriffmedia_civix_civicrm_enable(): void {
  _veriffmedia_civix_civicrm_config();
}

function _veriffmedia_civix_civicrm_uninstall(): void {
  _veriffmedia_civix_civicrm_config();
}

function _veriffmedia_civix_insert_navigation_menu(&$menu, $path, $item) {
  if (empty($path)) {
    $menu[] = [
      'attributes' => array_merge([
        'label' => $item['label'] ?? NULL,
        'active' => 1,
      ], $item),
    ];
    return TRUE;
  }
  else {
    foreach ($menu as &$entry) {
      if ($entry['attributes']['name'] ?? NULL) {
        if ($entry['attributes']['name'] == $path) {
          if (!isset($entry['child'])) {
            $entry['child'] = [];
          }
          $entry['child'][] = ['attributes' => $item];
          return TRUE;
        }
      }
    }
  }
  return FALSE;
}
