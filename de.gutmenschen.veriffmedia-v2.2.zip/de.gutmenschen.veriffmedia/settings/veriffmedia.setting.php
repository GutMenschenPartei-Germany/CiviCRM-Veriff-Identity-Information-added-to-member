<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Einstellungen der Extension. Werden über das Settings-Framework verwaltet
 * und erscheinen unter Administer → System Settings (bzw. eigene Maske).
 */
return [
  'veriffmedia_base_url' => [
    'name' => 'veriffmedia_base_url',
    'type' => 'String',
    'default' => 'https://stationapi.veriff.com/v1',
    'html_type' => 'text',
    'title' => E::ts('Veriff API Base-URL'),
    'description' => E::ts('Basis-URL der Veriff-API. Findest du im Veriff Customer Portal unter „All Integrations → Integration → API keys".'),
    'is_domain' => 1,
    'is_contact' => 0,
    'settings_pages' => ['veriffmedia' => ['weight' => 10]],
  ],
  'veriffmedia_api_key' => [
    'name' => 'veriffmedia_api_key',
    'type' => 'String',
    'default' => '',
    'html_type' => 'text',
    'title' => E::ts('Veriff API Public Key (X-AUTH-CLIENT)'),
    'description' => E::ts('Der öffentliche API-Key, der als Header X-AUTH-CLIENT gesendet wird.'),
    'is_domain' => 1,
    'is_contact' => 0,
    'settings_pages' => ['veriffmedia' => ['weight' => 20]],
  ],
  'veriffmedia_shared_secret' => [
    'name' => 'veriffmedia_shared_secret',
    'type' => 'String',
    'default' => '',
    'html_type' => 'text',
    'title' => E::ts('Veriff Shared Secret / Private Key'),
    'description' => E::ts('Das Shared Secret zur HMAC-SHA256-Signierung. Wird niemals an den Browser ausgeliefert.'),
    'is_domain' => 1,
    'is_contact' => 0,
    'settings_pages' => ['veriffmedia' => ['weight' => 30]],
  ],
  'veriffmedia_overwrite' => [
    'name' => 'veriffmedia_overwrite',
    'type' => 'Boolean',
    'default' => 1,
    'html_type' => 'checkbox',
    'title' => E::ts('Vorhandene Dateien überschreiben'),
    'description' => E::ts('Wenn aktiviert, werden bereits am Kontakt hinterlegte Veriff-Bilder beim erneuten Import ersetzt.'),
    'is_domain' => 1,
    'is_contact' => 0,
    'settings_pages' => ['veriffmedia' => ['weight' => 40]],
  ],
  // --- Automatischer Import über den CiviCRM-Cron ---
  'veriffmedia_auto_enabled' => [
    'name' => 'veriffmedia_auto_enabled',
    'type' => 'Boolean',
    'default' => 0,
    'html_type' => 'checkbox',
    'title' => E::ts('Automatischen Import aktivieren'),
    'description' => E::ts('Wenn aktiviert, holt CiviCRM beim regulären Cron-Lauf automatisch fehlende Bilder für verifizierte Kontakte. Standardmäßig AUS.'),
    'is_domain' => 1,
    'is_contact' => 0,
  ],
  'veriffmedia_auto_interval_min' => [
    'name' => 'veriffmedia_auto_interval_min',
    'type' => 'Integer',
    'default' => 60,
    'html_type' => 'text',
    'title' => E::ts('Mindestabstand zwischen Läufen (Minuten)'),
    'description' => E::ts('Wie oft der automatische Import höchstens ausgeführt wird. Standard: 60 Minuten.'),
    'is_domain' => 1,
    'is_contact' => 0,
  ],
  'veriffmedia_auto_limit' => [
    'name' => 'veriffmedia_auto_limit',
    'type' => 'Integer',
    'default' => 100,
    'html_type' => 'text',
    'title' => E::ts('Maximale Kontakte pro Lauf'),
    'description' => E::ts('Obergrenze der pro Lauf verarbeiteten Sessions. Standard: 100.'),
    'is_domain' => 1,
    'is_contact' => 0,
  ],
  'veriffmedia_auto_last_run' => [
    'name' => 'veriffmedia_auto_last_run',
    'type' => 'Integer',
    'default' => 0,
    'html_type' => 'text',
    'title' => E::ts('Letzter automatischer Lauf (intern)'),
    'description' => E::ts('Zeitstempel des letzten automatischen Laufs. Wird intern gesetzt.'),
    'is_domain' => 1,
    'is_contact' => 0,
  ],
];
