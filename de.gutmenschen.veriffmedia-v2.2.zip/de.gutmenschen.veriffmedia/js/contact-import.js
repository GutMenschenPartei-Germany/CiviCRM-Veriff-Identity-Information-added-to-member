/**
 * Veriff Media – Import-Panel auf der Kontakt-Detailseite.
 *
 * Die Veriff-Session wird serverseitig automatisch aus dem WordPress-Plugin
 * (Tabelle civiveriff_sessions) zum Kontakt ermittelt – es muss also keine
 * Session-ID mehr eingegeben werden. Ein Klick lädt Selfie, Vorder- und
 * Rückseite in die drei File-Custom-Felder des Kontakts.
 */
(function ($, CRM) {
  'use strict';

  CRM.$(function () {
    var cfg = (CRM.vars && CRM.vars.veriffmedia) || {};
    if (!cfg.contactId || !cfg.importUrl) {
      return;
    }

    // Panel nur einmal einfügen.
    if ($('#veriffmedia-panel').length) {
      return;
    }

    // Hinweiszeile je nachdem, ob schon eine Session bekannt ist.
    var sessionLine = cfg.hasSession
      ? ts('Es liegt eine Veriff-Session für diesen Kontakt vor.') +
        (cfg.sessionStatus ? ' (' + ts('Status') + ': ' + cfg.sessionStatus + ')' : '')
      : ts('Für diesen Kontakt wurde noch keine Veriff-Session gefunden.');

    var $panel = $(
      '<div id="veriffmedia-panel" class="crm-accordion-wrapper veriffmedia-panel">' +
        '<div class="crm-accordion-header">' + ts('Veriff-Verifikation') + '</div>' +
        '<div class="crm-accordion-body">' +
          '<div class="veriffmedia-session-line">' + sessionLine + '</div>' +
          '<div class="veriffmedia-row">' +
            '<button type="button" id="veriffmedia-btn" class="crm-button"' +
              (cfg.hasSession ? '' : ' disabled') + '>' +
              ts('Ausweisbilder abrufen') +
            '</button>' +
          '</div>' +
          '<div id="veriffmedia-status" class="veriffmedia-status" style="display:none;"></div>' +
          '<div class="veriffmedia-hint description">' +
            ts('Lädt Selfie, Ausweis-Vorderseite und -Rückseite aus der Veriff-Session und legt sie an diesem Kontakt ab.') +
          '</div>' +
        '</div>' +
      '</div>'
    );

    // Möglichst weit oben im Kontakt-Summary platzieren.
    var $target = $('#contactTopBar').length ? $('#contactTopBar') : $('.crm-summary-block').first();
    if ($target.length) {
      $target.after($panel);
    } else {
      $('#crm-main-content-wrapper').prepend($panel);
    }

    function setStatus(msg, type) {
      $('#veriffmedia-status')
        .removeClass('status-success status-error status-info')
        .addClass('status-' + (type || 'info'))
        .html(msg)
        .show();
    }

    $('#veriffmedia-btn').on('click', function () {
      var $btn = $(this);
      $btn.prop('disabled', true);
      setStatus(ts('Bilder werden von Veriff abgerufen …'), 'info');

      $.ajax({
        url: cfg.importUrl,
        method: 'POST',
        dataType: 'json',
        data: {
          contact_id: cfg.contactId,
          qfKey: cfg.qfKey
        }
      })
        .done(function (res) {
          if (res && res.success) {
            setStatus(
              (res.message || ts('Import erfolgreich.')) +
              '<br /><a href="javascript:void(0);" onclick="location.reload();">' +
              ts('Seite neu laden, um die Bilder zu sehen') + '</a>',
              'success'
            );
          } else {
            setStatus((res && res.message) || ts('Import fehlgeschlagen.'), 'error');
            $btn.prop('disabled', false);
          }
        })
        .fail(function () {
          setStatus(ts('Verbindungsfehler beim Import.'), 'error');
          $btn.prop('disabled', false);
        });
    });
  });

}(CRM.$ || jQuery, CRM));
