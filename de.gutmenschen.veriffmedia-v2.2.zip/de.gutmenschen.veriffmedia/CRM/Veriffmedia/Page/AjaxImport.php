<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * AJAX-Endpoint: Stößt den Import einer Veriff-Session für einen Kontakt an.
 *
 * Erwartet POST-Parameter:
 *   - contact_id (int)
 *
 * Die Veriff-Session-ID wird serverseitig automatisch aus dem WordPress-Plugin
 * ermittelt. Antwortet mit JSON.
 */
class CRM_Veriffmedia_Page_AjaxImport extends CRM_Core_Page {

  public function run() {
    // Nur POST zulassen.
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
      CRM_Utils_JSON::output([
        'success' => FALSE,
        'message' => E::ts('Ungültige Anfragemethode.'),
      ]);
      return;
    }

    // CSRF-Schutz über CiviCRM-Session-Key.
    $qfKey = CRM_Utils_Request::retrieve('qfKey', 'String', $this, FALSE, NULL, 'POST');
    if (!CRM_Core_Key::validate($qfKey, 'veriffmedia_import')) {
      // Fallback: prüfe Standard-Session-Berechtigung streng über die Permission unten.
      // (Key optional, aber empfohlen.)
    }

    $contactId = (int) CRM_Utils_Request::retrieve('contact_id', 'Positive', $this, FALSE, 0, 'POST');

    if (!$contactId) {
      CRM_Utils_JSON::output([
        'success' => FALSE,
        'message' => E::ts('Kontakt-ID ist erforderlich.'),
      ]);
      return;
    }

    // Berechtigung prüfen: darf dieser Nutzer den Kontakt bearbeiten?
    if (!CRM_Contact_BAO_Contact_Permission::allow($contactId, CRM_Core_Permission::EDIT)) {
      CRM_Utils_JSON::output([
        'success' => FALSE,
        'message' => E::ts('Keine Berechtigung, diesen Kontakt zu bearbeiten.'),
      ]);
      return;
    }

    try {
      $overwrite = (bool) Civi::settings()->get('veriffmedia_overwrite');
      $importer = new CRM_Veriffmedia_Importer();
      // Session-ID wird automatisch aus dem WordPress-Plugin ermittelt.
      $report = $importer->importForContact($contactId, $overwrite);

      $parts = [];
      if ($report['imported']) {
        $parts[] = E::ts('Importiert: %1', [1 => implode(', ', array_map([$this, 'labelFor'], $report['imported']))]);
      }
      if ($report['skipped']) {
        $parts[] = E::ts('Übersprungen (bereits vorhanden): %1', [1 => implode(', ', array_map([$this, 'labelFor'], $report['skipped']))]);
      }
      if ($report['errors']) {
        $parts[] = E::ts('Fehler: %1', [1 => implode(' | ', $report['errors'])]);
      }

      // Hinweis, wenn Veriff für diese Session gar keine Rückseite hat – damit
      // klar ist, dass zwei Bilder hier ein vollständiges Ergebnis sind.
      $available = $report['available'] ?? [];
      if ($available && !in_array('veriff_document_back', $available, TRUE)) {
        $parts[] = E::ts('Hinweis: Für diese Verifizierung liegt bei Veriff keine Ausweis-Rückseite vor (nur Selfie und Vorderseite).');
      }

      CRM_Utils_JSON::output([
        'success' => empty($report['errors']) || !empty($report['imported']),
        'message' => implode(' — ', $parts) ?: E::ts('Keine Änderungen.'),
        'report' => $report,
      ]);
    }
    catch (\Throwable $e) {
      CRM_Utils_JSON::output([
        'success' => FALSE,
        'message' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Interner Feldname -> lesbares Label.
   */
  protected function labelFor(string $suffix): string {
    $labels = [
      'veriff_selfie' => E::ts('Selfie'),
      'veriff_document_front' => E::ts('Vorderseite'),
      'veriff_document_back' => E::ts('Rückseite'),
    ];
    return $labels[$suffix] ?? $suffix;
  }

}
