<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Kern-Logik des automatischen Imports (vom Scheduled Job genutzt).
 *
 * Bewusst als eigenständige Klasse, damit sie unabhängig von der
 * API-Registrierung direkt aufgerufen werden kann – das umgeht Probleme mit
 * der APIv3-Job-Auflösung in neueren CiviCRM-Versionen.
 */
class CRM_Veriffmedia_Sync {

  /**
   * Führt einen Sync-Lauf aus.
   *
   * @param int $limit
   *   Höchstzahl der zu verarbeitenden approved-Sessions.
   * @param bool|null $overwrite
   *   NULL = Einstellung aus den Settings verwenden.
   *
   * @return array
   *   Statistik + Detailmeldungen des Laufs.
   *
   * @throws CRM_Core_Exception
   */
  public static function run(int $limit = 100, ?bool $overwrite = NULL): array {
    if (!CRM_Veriffmedia_WpBridge::isAvailable()) {
      throw new CRM_Core_Exception('WordPress-Umgebung/Plugin-Tabelle nicht verfügbar – der Sync funktioniert nur, wenn CiviCRM in derselben WordPress-Installation läuft und das Veriff-Plugin installiert ist.');
    }

    if ($overwrite === NULL) {
      $overwrite = (bool) Civi::settings()->get('veriffmedia_overwrite');
    }

    $sessions = CRM_Veriffmedia_WpBridge::getApprovedSessionsWithContact($limit);
    $importer = new CRM_Veriffmedia_Importer();

    $stats = [
      'candidates' => count($sessions),
      'imported' => 0,
      'already_complete' => 0,
      'skipped_no_contact' => 0,
      'failed' => 0,
    ];
    $details = [];

    foreach ($sessions as $session) {
      $contactId = (int) $session['contact_id'];
      $sessionId = (string) $session['session_id'];

      if ($contactId <= 0 || $sessionId === '') {
        $stats['skipped_no_contact']++;
        continue;
      }

      // Schneller lokaler Vorab-Check OHNE Veriff-Aufruf: Sind alle drei Felder
      // befüllt, ist der Kontakt sicher fertig (3-Bilder-Fall). Kontakte mit
      // nur zwei Bildern fallen hier durch und werden unten über importSession
      // geprüft – dabei wird nur nachgeladen, was fehlt.
      if (!$overwrite && $importer->contactHasAllThreeFieldsFilled($contactId)) {
        $stats['already_complete']++;
        continue;
      }

      try {
        $report = $importer->importSession($contactId, $sessionId, $overwrite);
        if (!empty($report['imported'])) {
          $stats['imported']++;
          $details[] = sprintf(
            'Kontakt #%d: %s importiert (%d Bild(er) bei Veriff vorhanden).',
            $contactId,
            implode(', ', $report['imported']),
            count($report['available'] ?? [])
          );
        }
        else {
          $stats['already_complete']++;
        }
      }
      catch (\Throwable $e) {
        $stats['failed']++;
        $details[] = sprintf('Kontakt #%d: Fehler – %s', $contactId, $e->getMessage());
        Civi::log()->warning('[veriffmedia] Sync-Fehler für Kontakt #' . $contactId . ': ' . $e->getMessage());
      }
    }

    $summary = sprintf(
      'Veriff-Sync: %d Kandidaten, %d importiert, %d bereits vollständig, %d ohne Kontakt, %d fehlgeschlagen.',
      $stats['candidates'],
      $stats['imported'],
      $stats['already_complete'],
      $stats['skipped_no_contact'],
      $stats['failed']
    );
    Civi::log()->info('[veriffmedia] ' . $summary);

    return [
      'stats' => $stats,
      'details' => $details,
      'summary' => $summary,
    ];
  }

}
