<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Dünner Client für die Veriff-Media-API.
 *
 * Zuständig für:
 *  - Auflisten der Medien einer Session (GET /sessions/{id}/media)
 *  - Herunterladen einer einzelnen Mediendatei (GET /media/{id})
 *
 * Authentifizierung:
 *  - Header X-AUTH-CLIENT = API Public Key
 *  - Header X-HMAC-SIGNATURE = HMAC-SHA256 des jeweils "zu signierenden Wertes"
 *    mit dem Shared Secret (Private Key). Beim Media-Download ist der zu
 *    signierende Wert die Media-ID; beim Media-Listing die Session-ID.
 */
class CRM_Veriffmedia_VeriffClient {

  /**
   * @var string
   */
  protected $baseUrl;

  /**
   * @var string
   */
  protected $apiKey;

  /**
   * @var string
   */
  protected $sharedSecret;

  public function __construct() {
    // Primär: eigene CiviCRM-Einstellungen. Fallback: Zugangsdaten aus dem
    // WordPress-Plugin (civiveriff_settings), damit nichts doppelt gepflegt
    // werden muss.
    $baseUrl = (string) Civi::settings()->get('veriffmedia_base_url');
    $apiKey = (string) Civi::settings()->get('veriffmedia_api_key');
    $secret = (string) Civi::settings()->get('veriffmedia_shared_secret');

    if ($apiKey === '' || $secret === '') {
      $wp = CRM_Veriffmedia_WpBridge::getCredentials();
      if ($apiKey === '') {
        $apiKey = $wp['api_key'];
      }
      if ($secret === '') {
        $secret = $wp['shared_secret'];
      }
      if ($baseUrl === '') {
        $baseUrl = $wp['base_url'];
      }
    }

    $this->baseUrl = $this->normalizeBaseUrl($baseUrl);
    $this->apiKey = $apiKey;
    $this->sharedSecret = $secret;
  }

  /**
   * Sorgt dafür, dass die Base-URL auf "/v1" endet.
   *
   * Das WP-Plugin speichert die Basis ohne Versionssuffix
   * (z.B. "https://stationapi.veriff.com"), die Media-Endpunkte liegen aber
   * unter "/v1/...". Wir ergänzen "/v1", falls es fehlt.
   */
  protected function normalizeBaseUrl(string $url): string {
    $url = rtrim(trim($url), '/');
    if ($url === '') {
      $url = 'https://stationapi.veriff.com';
    }
    if (!preg_match('#/v\d+$#', $url)) {
      $url .= '/v1';
    }
    return $url;
  }

  /**
   * Prüft, ob die Zugangsdaten konfiguriert sind.
   */
  public function isConfigured(): bool {
    return $this->apiKey !== '' && $this->sharedSecret !== '';
  }

  /**
   * HMAC-SHA256-Signatur eines Wertes (hex, lowercase) erzeugen.
   *
   * Veriff signiert je nach Endpunkt entweder die Session-ID, die Media-ID
   * oder – bei POST – den rohen Payload. Hier wird immer ein String signiert.
   */
  public function sign(string $payload): string {
    return hash_hmac('sha256', $payload, $this->sharedSecret);
  }

  /**
   * Liefert die Media-Metadaten einer Session.
   *
   * @return array
   *   Dekodierte Antwort mit u.a. dem Schlüssel "images" (Array von
   *   Objekten mit id, context, mimetype, ...).
   *
   * @throws CRM_Core_Exception
   */
  public function listSessionMedia(string $sessionId): array {
    $url = $this->baseUrl . '/sessions/' . rawurlencode($sessionId) . '/media';
    $signature = $this->sign($sessionId);

    $response = $this->request('GET', $url, $signature);
    $data = json_decode($response['body'], TRUE);

    if ($response['code'] !== 200 || !is_array($data)) {
      throw new CRM_Core_Exception(
        E::ts('Veriff-Media-Liste konnte nicht abgerufen werden (HTTP %1).', [1 => $response['code']])
        . ' ' . substr((string) $response['body'], 0, 500)
      );
    }

    return $data;
  }

  /**
   * Lädt eine einzelne Mediendatei herunter.
   *
   * @return array{content: string, mimetype: string}
   *   Binärer Dateiinhalt und (falls vom Server geliefert) MIME-Typ.
   *
   * @throws CRM_Core_Exception
   */
  public function downloadMedia(string $mediaId, string $fallbackMime = 'image/jpeg'): array {
    $url = $this->baseUrl . '/media/' . rawurlencode($mediaId);
    // WICHTIG: Beim Media-Download wird die MEDIA-ID signiert, nicht die URL.
    $signature = $this->sign($mediaId);

    $response = $this->request('GET', $url, $signature, TRUE);

    if ($response['code'] !== 200 || $response['body'] === '') {
      throw new CRM_Core_Exception(
        E::ts('Veriff-Mediendatei %1 konnte nicht geladen werden (HTTP %2).', [
          1 => $mediaId,
          2 => $response['code'],
        ])
      );
    }

    $mime = $response['content_type'] ?: $fallbackMime;
    // Query-Parameter aus dem Content-Type entfernen (z.B. "image/jpeg; charset=..")
    if (strpos($mime, ';') !== FALSE) {
      $mime = trim(explode(';', $mime)[0]);
    }

    return [
      'content' => $response['body'],
      'mimetype' => $mime,
    ];
  }

  /**
   * Führt eine HTTP-Anfrage gegen die Veriff-API aus.
   *
   * @param bool $binary
   *   TRUE, wenn der Body binär ist (Media-Download).
   *
   * @return array{code: int, body: string, content_type: string}
   *
   * @throws CRM_Core_Exception
   */
  protected function request(string $method, string $url, string $signature, bool $binary = FALSE): array {
    $headers = [
      'X-AUTH-CLIENT: ' . $this->apiKey,
      'X-HMAC-SIGNATURE: ' . $signature,
      'Accept: ' . ($binary ? '*/*' : 'application/json'),
    ];

    if (function_exists('curl_init')) {
      return $this->requestCurl($method, $url, $headers);
    }
    return $this->requestStream($method, $url, $headers);
  }

  /**
   * cURL-Variante (bevorzugt).
   */
  protected function requestCurl(string $method, string $url, array $headers): array {
    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $url,
      CURLOPT_CUSTOMREQUEST => $method,
      CURLOPT_HTTPHEADER => $headers,
      CURLOPT_RETURNTRANSFER => TRUE,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_CONNECTTIMEOUT => 10,
      CURLOPT_SSL_VERIFYPEER => TRUE,
      CURLOPT_SSL_VERIFYHOST => 2,
      CURLOPT_FOLLOWLOCATION => FALSE,
    ]);

    $body = curl_exec($ch);
    if ($body === FALSE) {
      $err = curl_error($ch);
      curl_close($ch);
      throw new CRM_Core_Exception(E::ts('Verbindung zu Veriff fehlgeschlagen: %1', [1 => $err]));
    }

    $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);

    return [
      'code' => $code,
      'body' => (string) $body,
      'content_type' => $contentType,
    ];
  }

  /**
   * Stream-Fallback, falls cURL nicht verfügbar ist.
   */
  protected function requestStream(string $method, string $url, array $headers): array {
    $context = stream_context_create([
      'http' => [
        'method' => $method,
        'header' => implode("\r\n", $headers),
        'timeout' => 30,
        'ignore_errors' => TRUE,
      ],
      'ssl' => [
        'verify_peer' => TRUE,
        'verify_peer_name' => TRUE,
      ],
    ]);

    $body = @file_get_contents($url, FALSE, $context);
    $code = 0;
    $contentType = '';

    if (isset($http_response_header) && is_array($http_response_header)) {
      foreach ($http_response_header as $headerLine) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $headerLine, $m)) {
          $code = (int) $m[1];
        }
        if (stripos($headerLine, 'Content-Type:') === 0) {
          $contentType = trim(substr($headerLine, strlen('Content-Type:')));
        }
      }
    }

    return [
      'code' => $code,
      'body' => $body === FALSE ? '' : $body,
      'content_type' => $contentType,
    ];
  }

}
