<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Brücke zum WordPress-Plugin "CiviCRM Veriff Membership Verification".
 *
 * Liest – ohne das Plugin zu verändern – dessen bereits vorhandene Daten:
 *  - die Veriff-Zugangsdaten aus der WP-Option "civiveriff_settings"
 *  - die Session-ID zu einem Kontakt aus der Tabelle {prefix}civiveriff_sessions
 *
 * Dadurch müssen Zugangsdaten nicht doppelt gepflegt und Session-IDs nicht
 * manuell abgetippt werden. Funktioniert nur, weil CiviCRM hier innerhalb
 * derselben WordPress-Installation läuft und $wpdb / get_option() erreichbar
 * sind.
 */
class CRM_Veriffmedia_WpBridge {

  const OPTION_KEY = 'civiveriff_settings';
  const TABLE_SUFFIX = 'civiveriff_sessions';

  /**
   * Ist die WordPress-Umgebung inkl. Plugin-Daten erreichbar?
   *
   * Prüft zusätzlich, ob die Tabelle des WordPress-Plugins wirklich existiert.
   * So liefern alle folgenden Methoden gefahrlos "nichts", falls das Plugin
   * nicht (mehr) installiert ist – statt in einen SQL-Fehler zu laufen.
   */
  public static function isAvailable(): bool {
    if (!function_exists('get_option') || !isset($GLOBALS['wpdb'])) {
      return FALSE;
    }
    try {
      global $wpdb;
      $table = $wpdb->prefix . self::TABLE_SUFFIX;
      $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
      return $found === $table;
    }
    catch (\Throwable $e) {
      return FALSE;
    }
  }

  /**
   * Liefert den vollen Tabellennamen inkl. WP-Präfix.
   */
  protected static function tableName(): string {
    global $wpdb;
    return $wpdb->prefix . self::TABLE_SUFFIX;
  }

  /**
   * Liest die Veriff-Zugangsdaten aus dem WordPress-Plugin.
   *
   * @return array{base_url:string, api_key:string, shared_secret:string}
   */
  public static function getCredentials(): array {
    $defaults = [
      'base_url' => 'https://stationapi.veriff.com',
      'api_key' => '',
      'shared_secret' => '',
    ];

    if (!self::isAvailable()) {
      return $defaults;
    }

    $opts = get_option(self::OPTION_KEY, []);
    if (!is_array($opts)) {
      return $defaults;
    }

    return [
      'base_url' => !empty($opts['base_url']) ? rtrim((string) $opts['base_url'], '/') : $defaults['base_url'],
      'api_key' => (string) ($opts['api_key'] ?? ''),
      'shared_secret' => (string) ($opts['shared_secret'] ?? ''),
    ];
  }

  /**
   * Ermittelt die jüngste Veriff-Session-ID für einen CiviCRM-Kontakt.
   *
   * Entspricht CiviVeriff_DB::get_latest_for_contact() im WP-Plugin.
   *
   * @return string|null  Session-ID oder NULL, wenn keine gefunden.
   */
  public static function getLatestSessionIdForContact(int $contactId): ?string {
    if (!self::isAvailable() || $contactId <= 0) {
      return NULL;
    }

    global $wpdb;
    $table = self::tableName();

    // Bevorzugt eine erfolgreich abgeschlossene Session; fällt sonst auf die
    // jüngste überhaupt vorhandene zurück.
    $sql = $wpdb->prepare(
      "SELECT session_id, status FROM {$table}
       WHERE contact_id = %d AND session_id <> ''
       ORDER BY (status = 'approved') DESC, id DESC
       LIMIT 1",
      $contactId
    );

    $row = $wpdb->get_row($sql, ARRAY_A);
    if (!$row || empty($row['session_id'])) {
      return NULL;
    }
    return (string) $row['session_id'];
  }

  /**
   * Liefert – falls vorhanden – Statusinfos zur jüngsten Session eines Kontakts.
   *
   * @return array{session_id:string, status:string}|null
   */
  public static function getLatestSessionInfoForContact(int $contactId): ?array {
    if (!self::isAvailable() || $contactId <= 0) {
      return NULL;
    }

    global $wpdb;
    $table = self::tableName();

    $sql = $wpdb->prepare(
      "SELECT session_id, status FROM {$table}
       WHERE contact_id = %d AND session_id <> ''
       ORDER BY (status = 'approved') DESC, id DESC
       LIMIT 1",
      $contactId
    );

    $row = $wpdb->get_row($sql, ARRAY_A);
    if (!$row || empty($row['session_id'])) {
      return NULL;
    }

    return [
      'session_id' => (string) $row['session_id'],
      'status' => (string) ($row['status'] ?? ''),
    ];
  }

  /**
   * Liefert erfolgreich verifizierte ("approved") Sessions mit gültiger
   * Kontakt-ID – als Grundlage für den automatischen Bild-Import per Cron.
   *
   * Pro Kontakt wird nur die jeweils jüngste approved-Session zurückgegeben.
   *
   * @param int $limit
   *   Höchstzahl der zurückgegebenen Sessions (Schutz vor sehr großen Läufen).
   *
   * @return array<int, array{contact_id:int, session_id:string, updated_at:string}>
   */
  public static function getApprovedSessionsWithContact(int $limit = 200): array {
    if (!self::isAvailable()) {
      return [];
    }

    global $wpdb;
    $table = self::tableName();
    $limit = max(1, min($limit, 1000));

    // Jüngste approved-Session je Kontakt: über eine Selbst-Aggregation der
    // höchsten id pro contact_id.
    $sql = $wpdb->prepare(
      "SELECT s.contact_id, s.session_id, s.updated_at
       FROM {$table} s
       INNER JOIN (
         SELECT contact_id, MAX(id) AS max_id
         FROM {$table}
         WHERE status = 'approved' AND contact_id > 0 AND session_id <> ''
         GROUP BY contact_id
       ) latest ON latest.max_id = s.id
       ORDER BY s.id DESC
       LIMIT %d",
      $limit
    );

    $rows = $wpdb->get_results($sql, ARRAY_A);
    if (!$rows) {
      return [];
    }

    $out = [];
    foreach ($rows as $row) {
      $out[] = [
        'contact_id' => (int) $row['contact_id'],
        'session_id' => (string) $row['session_id'],
        'updated_at' => (string) ($row['updated_at'] ?? ''),
      ];
    }
    return $out;
  }

}
