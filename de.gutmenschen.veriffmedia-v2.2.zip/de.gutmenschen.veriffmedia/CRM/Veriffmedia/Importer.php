<?php

use CRM_Veriffmedia_ExtensionUtil as E;

/**
 * Holt die Bilder einer Veriff-Session und legt sie an den drei
 * File-Custom-Feldern des Kontakts ab.
 */
class CRM_Veriffmedia_Importer {

  /**
   * Zuordnung: Veriff-"context" => internes Feld-Suffix.
   *
   * Veriff liefert je nach Flow leicht unterschiedliche Kontext-Bezeichner.
   * Wir normalisieren mehrere Schreibweisen auf unsere drei Zielfelder.
   */
  const CONTEXT_MAP = [
    // Selfie / Gesicht
    'face'            => 'veriff_selfie',
    'selfie'          => 'veriff_selfie',
    'portrait'        => 'veriff_selfie',
    // Ausweis Vorderseite
    'document-front'  => 'veriff_document_front',
    'document_front'  => 'veriff_document_front',
    'front'           => 'veriff_document_front',
    // Ausweis Rückseite
    'document-back'   => 'veriff_document_back',
    'document_back'   => 'veriff_document_back',
    'back'            => 'veriff_document_back',
  ];

  /**
   * @var CRM_Veriffmedia_VeriffClient
   */
  protected $client;

  public function __construct(?CRM_Veriffmedia_VeriffClient $client = NULL) {
    $this->client = $client ?: new CRM_Veriffmedia_VeriffClient();
  }

  /**
   * Importiert die Bilder für einen Kontakt, indem die Session-ID automatisch
   * aus dem WordPress-Plugin (Tabelle civiveriff_sessions) ermittelt wird.
   *
   * @param int $contactId
   * @param bool $overwrite
   *
   * @return array
   *   Report wie in importSession(); zusätzlich Schlüssel "sessionId".
   *
   * @throws CRM_Core_Exception
   */
  public function importForContact(int $contactId, bool $overwrite = TRUE): array {
    $sessionId = CRM_Veriffmedia_WpBridge::getLatestSessionIdForContact($contactId);

    if (!$sessionId) {
      throw new CRM_Core_Exception(
        E::ts('Für Kontakt #%1 wurde keine Veriff-Session gefunden. Wurde die Verifizierung über das Anmeldeformular durchgeführt?', [1 => $contactId])
      );
    }

    $report = $this->importSession($contactId, $sessionId, $overwrite);
    $report['sessionId'] = $sessionId;
    return $report;
  }

  /**
   * Schneller, rein lokaler Check: Sind alle drei Bildfelder befüllt?
   *
   * Ohne Veriff-Aufruf. Trifft dies zu, ist der Kontakt sicher vollständig
   * (mehr als drei Bilder gibt es nicht). Trifft es NICHT zu, heißt das nicht
   * zwingend "unvollständig" – der Kontakt könnte legitim nur zwei Bilder haben.
   * Für diese Unterscheidung dient contactHasAllExpectedImages().
   */
  public function contactHasAllThreeFieldsFilled(int $contactId): bool {
    $fieldKeys = $this->resolveCustomFieldKeys();
    if (count($fieldKeys) < 3) {
      return FALSE;
    }
    foreach ($fieldKeys as $customKey) {
      if (!$this->fieldHasFile($contactId, $customKey)) {
        return FALSE;
      }
    }
    return TRUE;
  }

  /**
   * Prüft, ob für einen Kontakt bereits alle Bilder vorliegen, die Veriff für
   * dessen Session tatsächlich bereitstellt.
   *
   * WICHTIG: Nicht jeder Kontakt hat drei Bilder. Manche haben nur Selfie +
   * Vorderseite (keine Rückseite). "Vollständig" heißt deshalb NICHT "alle drei
   * Felder befüllt", sondern "alle von Veriff für diese Session gelieferten
   * Bilder sind in CiviCRM vorhanden". Sonst würde der Cron-Job solche Kontakte
   * bei jedem Lauf erneut abarbeiten.
   *
   * @param int $contactId
   * @param string|null $sessionId
   *   Session-ID; wenn NULL, wird sie aus dem WP-Plugin ermittelt.
   *
   * @return bool
   *   TRUE, wenn nichts mehr zu importieren ist. Bei Unsicherheit (z.B. Session
   *   nicht abrufbar) FALSE, damit der Import es (erneut) versucht.
   */
  public function contactHasAllExpectedImages(int $contactId, ?string $sessionId = NULL): bool {
    $fieldKeys = $this->resolveCustomFieldKeys();
    if (count($fieldKeys) < 3) {
      // Felder (noch) nicht vollständig angelegt -> nicht als "fertig" werten.
      return FALSE;
    }

    if ($sessionId === NULL) {
      $sessionId = CRM_Veriffmedia_WpBridge::getLatestSessionIdForContact($contactId);
    }
    if (!$sessionId) {
      return FALSE;
    }

    // Welche Bilder liefert Veriff für diese Session wirklich?
    try {
      $expected = $this->getAvailableFieldsForSession($sessionId);
    }
    catch (\Throwable $e) {
      // Session gerade nicht abrufbar -> lieber später erneut versuchen.
      return FALSE;
    }

    if (!$expected) {
      // Noch keine Bilder bei Veriff (z.B. Verarbeitung läuft) -> nicht fertig.
      return FALSE;
    }

    // Gilt als vollständig, wenn jedes tatsächlich vorhandene Bild schon im
    // Kontakt liegt.
    foreach ($expected as $fieldSuffix) {
      if (empty($fieldKeys[$fieldSuffix]) || !$this->fieldHasFile($contactId, $fieldKeys[$fieldSuffix])) {
        return FALSE;
      }
    }
    return TRUE;
  }

  /**
   * Ermittelt, für welche der drei Zielfelder Veriff in einer Session ein Bild
   * bereitstellt (z.B. nur ['veriff_selfie', 'veriff_document_front'], wenn es
   * keine Rückseite gibt).
   *
   * @return array<int, string>  Liste der Feld-Suffixe.
   *
   * @throws CRM_Core_Exception
   */
  public function getAvailableFieldsForSession(string $sessionId): array {
    $media = $this->client->listSessionMedia($sessionId);
    $images = $media['images'] ?? [];

    $fields = [];
    foreach ($images as $image) {
      $context = strtolower((string) ($image['context'] ?? ''));
      if (isset(self::CONTEXT_MAP[$context])) {
        $suffix = self::CONTEXT_MAP[$context];
        if (!in_array($suffix, $fields, TRUE)) {
          $fields[] = $suffix;
        }
      }
    }
    return $fields;
  }

  /**
   * Hauptmethode: Medien einer Session in die Kontaktfelder importieren.
   *
   * @param int $contactId
   * @param string $sessionId
   * @param bool $overwrite
   *   TRUE = vorhandene Dateien im Feld ersetzen. FALSE = Feld mit
   *   bereits vorhandener Datei überspringen.
   *
   * @return array
   *   Report mit Schlüsseln: imported (Feldnamen), skipped, errors.
   *
   * @throws CRM_Core_Exception
   */
  public function importSession(int $contactId, string $sessionId, bool $overwrite = TRUE): array {
    if (!$this->client->isConfigured()) {
      throw new CRM_Core_Exception(E::ts('Veriff-Zugangsdaten sind nicht konfiguriert. Bitte unter Einstellungen hinterlegen.'));
    }
    $this->assertContactExists($contactId);

    $report = ['imported' => [], 'skipped' => [], 'errors' => [], 'available' => []];

    $media = $this->client->listSessionMedia($sessionId);
    $images = $media['images'] ?? [];

    if (!$images) {
      throw new CRM_Core_Exception(E::ts('Für diese Session wurden keine Bilder gefunden. Ist die Verifikation abgeschlossen?'));
    }

    // Feld-Metadaten (custom_N Schlüssel) einmalig auflösen.
    $fieldKeys = $this->resolveCustomFieldKeys();

    // Pro Zielfeld nur das erste passende Bild verwenden.
    $used = [];

    foreach ($images as $image) {
      $context = strtolower((string) ($image['context'] ?? ''));
      $mediaId = (string) ($image['id'] ?? '');

      if ($mediaId === '' || !isset(self::CONTEXT_MAP[$context])) {
        // Unbekannter Kontext (z.B. zusätzliche Dokumentenseiten) – ignorieren.
        continue;
      }

      $fieldSuffix = self::CONTEXT_MAP[$context];

      // Merken, dass Veriff für dieses Feld ein Bild bereitstellt. Wichtig:
      // Manche Kontakte haben nur Selfie + Vorderseite (keine Rückseite) –
      // dann taucht "veriff_document_back" hier gar nicht auf, und das ist
      // korrekt so (kein fehlendes Bild, sondern schlicht keins vorhanden).
      if (!in_array($fieldSuffix, $report['available'], TRUE)) {
        $report['available'][] = $fieldSuffix;
      }

      if (isset($used[$fieldSuffix])) {
        // Für dieses Feld haben wir schon ein Bild übernommen.
        continue;
      }
      if (!isset($fieldKeys[$fieldSuffix])) {
        $report['errors'][] = E::ts('Zielfeld %1 existiert nicht in CiviCRM.', [1 => $fieldSuffix]);
        continue;
      }

      $customKey = $fieldKeys[$fieldSuffix];

      // Bereits belegt und kein Overwrite?
      if (!$overwrite && $this->fieldHasFile($contactId, $customKey)) {
        $report['skipped'][] = $fieldSuffix;
        $used[$fieldSuffix] = TRUE;
        continue;
      }

      try {
        $fallbackMime = (string) ($image['mimetype'] ?? 'image/jpeg');
        $file = $this->client->downloadMedia($mediaId, $fallbackMime);

        $filename = $this->buildFilename($fieldSuffix, $file['mimetype']);
        $this->storeFileOnContact($contactId, $customKey, $file['content'], $filename, $file['mimetype']);

        $report['imported'][] = $fieldSuffix;
        $used[$fieldSuffix] = TRUE;
      }
      catch (\Throwable $e) {
        $report['errors'][] = E::ts('%1: %2', [1 => $fieldSuffix, 2 => $e->getMessage()]);
      }
    }

    if (!$report['imported'] && !$report['skipped']) {
      throw new CRM_Core_Exception(
        E::ts('Es konnten keine Bilder aus der Veriff-Session übernommen werden.')
        . ($report['errors'] ? ' ' . implode(' | ', $report['errors']) : '')
      );
    }

    return $report;
  }

  /**
   * Speichert eine Binärdatei in einem File-Custom-Field eines Kontakts.
   *
   * Vorgehen:
   *  1. Datei physisch ins CiviCRM-custom-Upload-Verzeichnis schreiben.
   *  2. Eintrag in civicrm_file anlegen (via File-BAO).
   *  3. civicrm_entity_file verknüpfen und den Custom-Field-Wert setzen.
   *
   * CiviCRM verwaltet File-Custom-Fields über die File-Entity; wir nutzen
   * die dafür vorgesehene Custom_Value-Save-Logik.
   *
   * @throws CRM_Core_Exception
   */
  protected function storeFileOnContact(int $contactId, string $customKey, string $content, string $filename, string $mimeType): void {
    // Zielverzeichnis: CiviCRM custom upload dir.
    $config = CRM_Core_Config::singleton();
    $uploadDir = rtrim($config->customFileUploadDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

    if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0755, TRUE) && !is_dir($uploadDir)) {
      throw new CRM_Core_Exception(E::ts('Upload-Verzeichnis %1 ist nicht beschreibbar.', [1 => $uploadDir]));
    }

    // Kollisionsfreien Dateinamen erzeugen und Datei physisch schreiben.
    $safeName = CRM_Utils_File::makeFileName($filename);
    $targetPath = $uploadDir . $safeName;

    if (file_put_contents($targetPath, $content) === FALSE) {
      throw new CRM_Core_Exception(E::ts('Datei konnte nicht geschrieben werden: %1', [1 => $targetPath]));
    }
    @chmod($targetPath, 0644);

    // custom_N -> reine Field-ID extrahieren.
    $fieldId = (int) substr($customKey, strlen('custom_'));

    // Vorhandene Datei am Feld (falls Overwrite) sauber entfernen,
    // damit keine verwaisten civicrm_file-Einträge zurückbleiben.
    $this->deleteExistingFile($contactId, $fieldId);

    // File-Custom-Fields werden NICHT über ein Array an setValues() gesetzt
    // (das lehnen neuere CiviCRM-Versionen mit "Array hat nicht den richtigen
    // Feld Daten Typ: File" ab). Korrekt ist:
    //   1. einen civicrm_file-Datensatz anlegen,
    //   2. ihn per civicrm_entity_file mit dem Kontakt verknüpfen,
    //   3. die File-ID (nicht den Pfad) als Custom-Feld-Wert speichern.

    // 1. File-Datensatz anlegen.
    $fileDAO = new CRM_Core_DAO_File();
    $fileDAO->uri = $safeName;
    $fileDAO->mime_type = $mimeType;
    $fileDAO->file_type_id = NULL;
    $fileDAO->upload_date = date('YmdHis');
    $fileDAO->save();
    $fileId = (int) $fileDAO->id;

    if (!$fileId) {
      throw new CRM_Core_Exception(E::ts('File-Datensatz konnte nicht angelegt werden.'));
    }

    // 2. Entity-File-Verknüpfung anlegen (Kontakt <-> Datei).
    $entityFileDAO = new CRM_Core_DAO_EntityFile();
    $entityFileDAO->entity_table = 'civicrm_contact';
    $entityFileDAO->entity_id = $contactId;
    $entityFileDAO->file_id = $fileId;
    $entityFileDAO->save();

    // 3. Die File-ID als Wert des Custom-Feldes speichern.
    // setValues() nimmt den Parameter per Referenz entgegen – ein inline
    // übergebenes Array lehnt PHP hier ab. Daher erst in eine Variable legen.
    $setParams = [
      'entityID' => $contactId,
      $customKey => $fileId,
    ];
    CRM_Core_BAO_CustomValueTable::setValues($setParams);
  }

  /**
   * Entfernt eine ggf. am Feld hängende Datei (Datensatz + physisch),
   * damit beim Overwrite keine Waisen zurückbleiben.
   */
  protected function deleteExistingFile(int $contactId, int $fieldId): void {
    $customKey = 'custom_' . $fieldId;
    $getParams = [
      'entityID' => $contactId,
      'return.' . $customKey => 1,
    ];
    $current = CRM_Core_BAO_CustomValueTable::getValues($getParams);

    $oldFileId = $current[$customKey] ?? NULL;
    if (!$oldFileId) {
      return;
    }

    try {
      // Entfernt den civicrm_file-Datensatz, die civicrm_entity_file-
      // Verknüpfung und die physische Datei auf der Platte.
      CRM_Core_BAO_File::deleteFileReferences((int) $oldFileId, $contactId, $fieldId);
    }
    catch (\Throwable $e) {
      // Nicht fatal – der Feldwert wird ohnehin gleich überschrieben.
      Civi::log()->warning('[veriffmedia] Alte Datei konnte nicht vollständig entfernt werden: ' . $e->getMessage());
    }
  }

  /**
   * Prüft, ob ein Feld für den Kontakt bereits eine Datei enthält.
   */
  protected function fieldHasFile(int $contactId, string $customKey): bool {
    $getParams = [
      'entityID' => $contactId,
      'return.' . $customKey => 1,
    ];
    $values = CRM_Core_BAO_CustomValueTable::getValues($getParams);
    return !empty($values[$customKey]);
  }

  /**
   * Liefert die custom_N-Schlüssel der drei Zielfelder.
   *
   * @return array<string,string>
   *   z.B. ['veriff_selfie' => 'custom_42', ...]
   */
  protected function resolveCustomFieldKeys(): array {
    $names = ['veriff_selfie', 'veriff_document_front', 'veriff_document_back'];

    $fields = \Civi\Api4\CustomField::get(FALSE)
      ->addSelect('id', 'name')
      ->addWhere('name', 'IN', $names)
      ->addWhere('custom_group_id.name', '=', 'veriff_verifikation')
      ->execute();

    $map = [];
    foreach ($fields as $f) {
      $map[$f['name']] = 'custom_' . $f['id'];
    }
    return $map;
  }

  /**
   * Baut einen sprechenden Dateinamen inkl. Kontakt-ID und Endung.
   */
  protected function buildFilename(string $fieldSuffix, string $mimeType): string {
    $ext = $this->extensionForMime($mimeType);
    $stamp = date('Ymd_His');
    return sprintf('%s_%s.%s', str_replace('veriff_', 'veriff-', $fieldSuffix), $stamp, $ext);
  }

  /**
   * MIME-Typ -> Dateiendung.
   */
  protected function extensionForMime(string $mime): string {
    $map = [
      'image/jpeg' => 'jpg',
      'image/jpg' => 'jpg',
      'image/png' => 'png',
      'image/webp' => 'webp',
      'application/pdf' => 'pdf',
    ];
    return $map[strtolower($mime)] ?? 'jpg';
  }

  /**
   * @throws CRM_Core_Exception
   */
  protected function assertContactExists(int $contactId): void {
    $exists = \Civi\Api4\Contact::get(FALSE)
      ->addWhere('id', '=', $contactId)
      ->addWhere('is_deleted', '=', FALSE)
      ->selectRowCount()
      ->execute()
      ->countMatched();

    if (!$exists) {
      throw new CRM_Core_Exception(E::ts('Kontakt #%1 wurde nicht gefunden.', [1 => $contactId]));
    }
  }

}
